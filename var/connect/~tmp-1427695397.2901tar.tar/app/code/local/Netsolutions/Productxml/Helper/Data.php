<?php
class Netsolutions_Productxml_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 