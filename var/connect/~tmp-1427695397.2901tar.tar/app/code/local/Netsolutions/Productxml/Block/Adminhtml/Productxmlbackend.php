<?php  

class Netsolutions_Productxml_Block_Adminhtml_Productxmlbackend extends Mage_Adminhtml_Block_Template {

}